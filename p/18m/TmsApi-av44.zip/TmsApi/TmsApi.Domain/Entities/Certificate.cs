using System;

namespace TmsApi.Domain.Entities;

public class Certificate
{
    public int Id { get; set; }                        // surrogate primary key
    public required string SerialNumber { get; set; }  // natural key — human-readable

    public DateTime IssuedAt { get; set; } = DateTime.UtcNow;

    // Foreign keys + navigation to the student and course
    public int StudentId { get; set; }
    public int CourseId { get; set; }
    public Student Student { get; set; } = null!;
    public Course Course { get; set; } = null!;
}