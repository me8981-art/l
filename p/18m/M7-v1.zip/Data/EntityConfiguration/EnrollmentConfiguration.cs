using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace TmsApi.Entities;
public class EnrollmentConfiguration : IEntityTypeConfiguration<Enrollment>
{
	
	public void Configure(EntityTypeBuilder<Enrollment> builder)
    {          
		builder.HasKey(e => e.Id);
        builder.Property(e => e.EnrolledAt)
               .IsRequired();

		builder.HasOne(e => e.Student)
			.WithMany(s => s.Enrollments)
			.HasForeignKey(e => e.StudentId)
            .OnDelete(DeleteBehavior.Restrict);  

		builder.HasOne(e => e.Course)
			.WithMany(c => c.Enrollments)
			.HasForeignKey(e => e.CourseId)
			.OnDelete(DeleteBehavior.Restrict);
  
}
}