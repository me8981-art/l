using Microsoft.EntityFrameworkCore;
using Tms.Api.Dtos;
using Tms.Api.Services;
using TmsApi.Data;
using TmsApi.Entities;

public class EnrollmentService(TmsDbContext context, ILogger<EnrollmentService> logger) : IEnrollmentService
{
    public Task<EnrollmentResponseDto?> GetByCourseAsync(int courseId, int id, CancellationToken ct) =>
        context.Enrollments
        .AsNoTracking()
        .Where(e => e.Id == id && e.CourseId == courseId)
        .Select(e => new EnrollmentResponseDto(e.Id, e.CourseId, e.StudentId, e.EnrolledAt))
        .FirstOrDefaultAsync(ct);
 
    public async Task<EnrollmentResponseDto> CreateAsync(
    int courseId,
    EnrollStudentRequest request,
    CancellationToken ct)
    {
        var enrollment = new Enrollment
        {
            CourseId = courseId,
            StudentId = request.StudentId,
            EnrolledAt = DateTime.UtcNow
        };

        context.Enrollments.Add(enrollment);

        await context.SaveChangesAsync(ct);

        logger.LogInformation(
            "Student {StudentId} enrolled in course {CourseId} with EnrollmentId {EnrollmentId}",
            request.StudentId,
            courseId,
            enrollment.Id);

        return await GetByCourseAsync(courseId, enrollment.Id, ct)
            ?? throw new InvalidOperationException(
                "Enrollment was created but could not be retrieved.");
    }
}