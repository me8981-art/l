using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
// using MediatR;

namespace TmsApi.Api.Controllers.V2;

[ApiController]
[Route("api/v2/transcripts")]
public class TranscriptsController : ControllerBase
{
    [HttpPost]
    [EnableRateLimiting("transcripts")]
    public IActionResult RequestTranscript([FromBody] object? _)
    {
        // Stub only.
        // Exercise 5 will enqueue a background job and return 202 Accepted.
        return Ok();
    }

    // [HttpGet("search")]
    // [EnableRateLimiting("search")]
    // public async Task<IActionResult> SearchCourses(
    //     [FromQuery] string? term, CancellationToken ct)
    // {
    //     var results = await mediator.Send(new SearchCoursesQuery(term), ct);
    //     return Ok(results);
    // }
}